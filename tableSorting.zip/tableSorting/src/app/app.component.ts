import { Component, OnInit  } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  public data : any
  title = 'tableSorting';


  ngOnInit() {
    this.data = [
    {'name':'Anil', 'email' :'abc1@gmail.com', 'age' :'24', 'city':'Noida' },
    {'name':'Sunil', 'email' :'abc2@gmail.com', 'age' :'24', 'city':'Noida' },
    {'name':'Alok', 'email' :'abc3@gmail.com', 'age' :'44', 'city':'Noida' },
    {'name':'Tinku', 'email' :'abc4@gmail.com', 'age' :'14', 'city':'Noida' },
    {'name':'XYZ', 'email' :'abc5@gmail.com', 'age' :'32', 'city':'Noida' },
    {'name':'asas', 'email' :'ab6c@gmail.com', 'age' :'11', 'city':'Noida' },
    {'name':'erer', 'email' :'abc7@gmail.com', 'age' :'22', 'city':'Noida' },
    {'name':'jhjh', 'email' :'abc8@gmail.com', 'age' :'26', 'city':'Noida' },
    {'name':'Anil', 'email' :'abc1@gmail.com', 'age' :'24', 'city':'Noida' },
    {'name':'Sunil', 'email' :'abc2@gmail.com', 'age' :'24', 'city':'Noida' },
    {'name':'Alok', 'email' :'abc3@gmail.com', 'age' :'44', 'city':'Noida' },
    {'name':'Tinku', 'email' :'abc4@gmail.com', 'age' :'14', 'city':'Noida' },
    {'name':'XYZ', 'email' :'abc5@gmail.com', 'age' :'32', 'city':'Noida' },
    {'name':'asas', 'email' :'ab6c@gmail.com', 'age' :'11', 'city':'Noida' },
    {'name':'erer', 'email' :'abc7@gmail.com', 'age' :'22', 'city':'Noida' },
    {'name':'jhjh', 'email' :'abc8@gmail.com', 'age' :'26', 'city':'Noida' },
    {'name':'Anil', 'email' :'abc1@gmail.com', 'age' :'24', 'city':'Noida' },
    {'name':'Sunil', 'email' :'abc2@gmail.com', 'age' :'24', 'city':'Noida' },
    {'name':'Alok', 'email' :'abc3@gmail.com', 'age' :'44', 'city':'Noida' },
    {'name':'Tinku', 'email' :'abc4@gmail.com', 'age' :'14', 'city':'Noida' },
    {'name':'XYZ', 'email' :'abc5@gmail.com', 'age' :'32', 'city':'Noida' },
    {'name':'asas', 'email' :'ab6c@gmail.com', 'age' :'11', 'city':'Noida' },
    {'name':'erer', 'email' :'abc7@gmail.com', 'age' :'22', 'city':'Noida' },
    {'name':'jhjh', 'email' :'abc8@gmail.com', 'age' :'26', 'city':'Noida' }
   ]
  }

}
